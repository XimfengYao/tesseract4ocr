const express = require('express');
const app = express();
const bodyParser = require('body-parser');
var result = require('./model/result');
const tools = require('./tools.js');


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Credentials", "true");
  res.header("Access-Control-Expose-Headers", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type,Access-Token");
    res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
    res.header("X-Powered-By",'3.2.1')
    //res.header("Content-Type","application/json;charset=utf-8");
    if (req.method=="OPTIONS") {
      res.send(200);
      return;
    }
    next();
});

app.post('/ocr-server/:qtype',function(req,res){
    if(req.params.qtype=='base64'){
      var imageData=req.body.imageData;
      if(! imageData){
        res.json(result.resData(result.resHeadError("无图片64位数据！！"),null));
      }
      tools.analysis_process_base64(imageData,function(data,state,message){
        res.json(result.resData(result.resHead(state,message),data));
      }); 
    }else if(req.params.qtype=='url'){
      var url=req.body.url;
      if(! url){
        res.json(result.resData(result.resHeadError("请输入下载路径"),null));
      }
      tools.analysis_process_url(url,function(data,state,message){
        res.json(result.resData(result.resHead(state,message),data));
      });
    }else{
      res.json(result.resData(result.resHeadError("无效路径参数"),null));
    }　　

});



app.listen(8080);