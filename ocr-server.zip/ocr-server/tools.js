var fs = require("fs");
var request = require("request");
var shell = require("child_process");
const path = require('path');
const config = require('./config.js');

// const base64 = require('node-base64-image');
// const options = {local: true};
// async function  to_image(){	
// 	console.log("-----------------");
// 	//const result=await base64.encode("C:\\Users\\unisure\\Desktop\\t\\1.jpg",options);
// 	let bitmap =fs.readFileSync("C:\\Users\\unisure\\Desktop\\t\\1.jpg");
// 	let base64str = Buffer.from(bitmap, 'binary').toString('base64'); // base64编码
// 	console.log(base64str);
// 	var dataBuffer = new Buffer(base64str, 'base64'); // 解码图片
//     // var dataBuffer = Buffer.from(base64Data, 'base64'); // 这是另一种写法
//     fs.writeFile("C:\\Users\\unisure\\Desktop\\t\\x.jpg", dataBuffer, function(err) {
//         if(err){
//           console.log(err);
//         }else{
//           console.log("保存成功！");
//         }
//     });
// }	
// to_image();
var stata_sb="0";
var stata_cg="1";
function execCommand(fileName,begtime,callback) {
	var full_fn=path.join(config.image_root_path, fileName);
	var cmd="tesseract "+full_fn+" "+full_fn+"_res -l chi_sim+eng";
	console.log(cmd);
	try{
		shell.exec(cmd,function(error, stdout, stderr) {
        	if(error){
               callback(null,stata_sb,"解析失败:"+error);
            } else{
            	var mssage="识别成功,耗时："+(new Date().getTime()-begtime)+" 毫秒！";
             	fs.readFile(full_fn+"_res.txt",(err,data) => {
              		callback(data.toString(),stata_cg,mssage);
           		});
          	}
        });
	}catch(err){
		callback(null,stata_sb,"转换命令执行失败！"+err);
    }
}

var sl=0;


exports.analysis_process_base64=function(base64str,callback){
	sl++;
    let fileName = "ocr-" +new Date().getTime()+"-"+ sl ;
	try{
		var base64 = base64str.replace(/^data:image\/\w+;base64,/, ""); //去掉图片base64码前面部分data:image/png;base64
	    var dataBuffer = new Buffer(base64, 'base64'); // 解码图片
	    fs.writeFile(path.join(config.image_root_path, fileName), dataBuffer, function(err) {
	        if(err){
	          console.log("保存错误！");
	          callback(null,stata_sb,"图片转换错误");
	        }else{
	          console.log("保存成功！");          
	          execCommand(fileName,new Date().getTime(),callback);
	        }
	    });
    }catch(err){
		callback(null,stata_sb,"图片转换错误！"+err);
    }
}

exports.analysis_process_url=function(image_url,callback){  
  	sl++;
    let fileName = "ocr-" +new Date().getTime()+"-"+ sl ;
    let url = image_url;
    let stream = fs.createWriteStream(path.join(config.image_root_path, fileName));
    try{
    	request(url).pipe(stream).on("close",function (err) {
	    	if(err){
	    		callback(null,stata_sb,"文件下载错误！");
	    	}else{    		
	          console.log("文件[" + fileName + "]下载完毕");
	          execCommand(fileName,new Date().getTime(),callback);
	    	}
      	});
    }catch(err){
		callback(null,stata_sb,"文件下载错误！"+err);
    }
    
}

