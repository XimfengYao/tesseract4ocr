exports.resData = function(resHead, resbody) {
	var result = {};
	result.head = resHead;
	result.resBody = resbody;
	return result;
};

exports.resHead = function(state, message) {
	var result = {};
	result.state = state;
	result.message = message;
	return result;
};
exports.resHeadSuccess = function(message) {
	var result = {};
	result.state = 1;
	result.message = message;
	return result;
};
exports.resHeadError = function(message) {
	var result = {};
	result.state = 0;
	result.message = message;
	return result;
};
exports.resHead = function(state,message) {
	var result = {};
	result.state = state;
	result.message = message;
	return result;
};
