module.exports = {
	image_root_path: '/home/wh/ocr',
	url_root_path:''
};